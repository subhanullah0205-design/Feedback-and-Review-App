# Feedback and Review App

Flutter + Firebase mobile app to collect, manage and analyze feedback.

![Overview](docs/images/feedback_1_overview.png)

## Features
- Firebase email/password authentication with two roles: **user** and **admin**
- Users submit reviews: category (Course/Task/Service/App/Other), subject, 1-5 star rating, comment
- Users see their own submissions and whether each is Pending or Reviewed
- Admin dashboard (real-time via Firestore streams): total feedback, average rating, pending count, rating distribution, feedback per category
- Admin can filter all feedback by category, mark items reviewed/pending, and delete items

![Features](docs/images/feedback_2_features.png)
![Tech stack](docs/images/feedback_3_techstack.png)

*Images are design previews of the app screens.*

## Structure
```
lib/main.dart                      auth gate + role-based routing
lib/models.dart                    FeedbackItem model, categories
lib/services/firebase_service.dart auth, roles, feedback CRUD, streams
lib/screens/                       login, user_home, admin_dashboard
```

## Setup
1. `flutter create --org pk.internee --project-name feedback_review_app .` (keep existing lib/ and pubspec.yaml)
2. `flutter pub get`
3. Firebase console: create project, enable Email/Password auth, create Firestore database.
4. `flutterfire configure`, then use `DefaultFirebaseOptions.currentPlatform` in `main.dart`.
5. Android: add INTERNET permission, set minSdk 23.
6. `flutter run`

## Creating an admin
Sign up normally, then in Firestore open `users/<that user's uid>` and change `role` from `user` to `admin`. Log in again.

## Firestore rules
```
rules_version = '2';
service cloud.firestore {
  match /databases/{db}/documents {
    function isAdmin() {
      return get(/databases/$(db)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
    match /users/{uid} {
      allow read: if request.auth != null && (request.auth.uid == uid || isAdmin());
      allow create: if request.auth.uid == uid && request.resource.data.role == 'user';
    }
    match /feedback/{id} {
      allow create: if request.auth != null && request.resource.data.uid == request.auth.uid;
      allow read: if request.auth != null && (resource.data.uid == request.auth.uid || isAdmin());
      allow update, delete: if request.auth != null && isAdmin();
    }
  }
}
```

## Author
Subhan Ullah
