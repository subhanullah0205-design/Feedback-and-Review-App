import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'screens/admin_dashboard.dart';
import 'screens/login_screen.dart';
import 'screens/user_home.dart';
import 'services/firebase_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // switch to DefaultFirebaseOptions if you used flutterfire configure
  runApp(const FeedbackApp());
}

class FeedbackApp extends StatelessWidget {
  const FeedbackApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Feedback & Review',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true),
        home: StreamBuilder<User?>(
          stream: FirebaseService.authState,
          builder: (c, s) {
            if (s.connectionState == ConnectionState.waiting) return const _Loading();
            if (!s.hasData) return const LoginScreen();
            return FutureBuilder<String>(
              future: FirebaseService.role(),
              builder: (c, r) {
                if (!r.hasData) return const _Loading();
                return r.data == 'admin' ? const AdminDashboard() : const UserHome();
              },
            );
          },
        ),
      );
}

class _Loading extends StatelessWidget {
  const _Loading();
  @override
  Widget build(BuildContext context) =>
      const Scaffold(body: Center(child: CircularProgressIndicator()));
}
