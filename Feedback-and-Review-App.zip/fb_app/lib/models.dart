import 'package:cloud_firestore/cloud_firestore.dart';

const categories = ['Course', 'Task', 'Service', 'App', 'Other'];

class FeedbackItem {
  final String id, uid, email, category, subject, comment, status;
  final int rating;
  final DateTime? createdAt;
  FeedbackItem({required this.id, required this.uid, required this.email,
      required this.category, required this.subject, required this.comment,
      required this.status, required this.rating, this.createdAt});

  factory FeedbackItem.fromDoc(QueryDocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data();
    return FeedbackItem(
      id: d.id,
      uid: m['uid'] ?? '',
      email: m['email'] ?? '',
      category: m['category'] ?? 'Other',
      subject: m['subject'] ?? '',
      comment: m['comment'] ?? '',
      status: m['status'] ?? 'new',
      rating: (m['rating'] ?? 0) as int,
      createdAt: (m['createdAt'] as Timestamp?)?.toDate(),
    );
  }
}
