import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models.dart';

class FirebaseService {
  static final _auth = FirebaseAuth.instance;
  static final _db = FirebaseFirestore.instance;
  static User get user => _auth.currentUser!;

  static Stream<User?> get authState => _auth.authStateChanges();
  static Future<void> login(String e, String p) =>
      _auth.signInWithEmailAndPassword(email: e, password: p);
  static Future<void> logout() => _auth.signOut();

  static Future<void> register(String name, String e, String p) async {
    final c = await _auth.createUserWithEmailAndPassword(email: e, password: p);
    await _db.collection('users').doc(c.user!.uid)
        .set({'name': name, 'email': e, 'role': 'user'});
  }

  /// Role is 'user' or 'admin'. Make someone admin by editing users/{uid}.role in the Firebase console.
  static Future<String> role() async {
    final d = await _db.collection('users').doc(user.uid).get();
    return d.data()?['role'] ?? 'user';
  }

  static Future<void> submit(String category, String subject, int rating, String comment) =>
      _db.collection('feedback').add({
        'uid': user.uid, 'email': user.email, 'category': category,
        'subject': subject, 'rating': rating, 'comment': comment,
        'status': 'new', 'createdAt': FieldValue.serverTimestamp(),
      });

  static Stream<List<FeedbackItem>> myFeedback() => _db.collection('feedback')
      .where('uid', isEqualTo: user.uid).snapshots().map((s) {
        final l = s.docs.map(FeedbackItem.fromDoc).toList();
        l.sort((a, b) => (b.createdAt ?? DateTime.now()).compareTo(a.createdAt ?? DateTime.now()));
        return l;
      });

  static Stream<List<FeedbackItem>> allFeedback() => _db.collection('feedback')
      .orderBy('createdAt', descending: true).snapshots()
      .map((s) => s.docs.map(FeedbackItem.fromDoc).toList());

  static Future<void> setStatus(String id, String status) =>
      _db.collection('feedback').doc(id).update({'status': status});
  static Future<void> delete(String id) => _db.collection('feedback').doc(id).delete();
}
