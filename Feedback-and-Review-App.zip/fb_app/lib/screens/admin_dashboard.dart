import 'package:flutter/material.dart';
import '../models.dart';
import '../services/firebase_service.dart';
import 'user_home.dart' show Stars;

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});
  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  int _tab = 0;
  String _filter = 'All';

  @override
  Widget build(BuildContext context) => StreamBuilder<List<FeedbackItem>>(
        stream: FirebaseService.allFeedback(), // real-time updates
        builder: (c, s) {
          final all = s.data ?? [];
          return Scaffold(
            appBar: AppBar(title: const Text('Admin Dashboard'), actions: [
              IconButton(icon: const Icon(Icons.logout), onPressed: FirebaseService.logout),
            ]),
            body: !s.hasData
                ? const Center(child: CircularProgressIndicator())
                : (_tab == 0 ? _insights(all) : _list(all)),
            bottomNavigationBar: NavigationBar(
              selectedIndex: _tab,
              onDestinationSelected: (i) => setState(() => _tab = i),
              destinations: const [
                NavigationDestination(icon: Icon(Icons.insights), label: 'Insights'),
                NavigationDestination(icon: Icon(Icons.list_alt), label: 'All feedback'),
              ],
            ),
          );
        },
      );

  Widget _stat(String label, String value, IconData icon) => Expanded(
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(children: [
              Icon(icon, color: Colors.teal),
              Text(value, style: Theme.of(context).textTheme.headlineSmall),
              Text(label, style: const TextStyle(fontSize: 12)),
            ]),
          ),
        ),
      );

  Widget _bar(String label, int count, int total) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(children: [
          SizedBox(width: 70, child: Text(label)),
          Expanded(child: LinearProgressIndicator(value: total == 0 ? 0 : count / total, minHeight: 10)),
          SizedBox(width: 36, child: Text('  $count')),
        ]),
      );

  Widget _insights(List<FeedbackItem> all) {
    final total = all.length;
    final avg = total == 0 ? 0.0 : all.map((f) => f.rating).reduce((a, b) => a + b) / total;
    final pending = all.where((f) => f.status == 'new').length;
    return ListView(padding: const EdgeInsets.all(12), children: [
      Row(children: [
        _stat('Total', '$total', Icons.feedback),
        _stat('Avg rating', avg.toStringAsFixed(1), Icons.star),
        _stat('Pending', '$pending', Icons.pending_actions),
      ]),
      const SizedBox(height: 12),
      Text('Rating distribution', style: Theme.of(context).textTheme.titleMedium),
      for (var r = 5; r >= 1; r--) _bar('$r star', all.where((f) => f.rating == r).length, total),
      const SizedBox(height: 16),
      Text('By category', style: Theme.of(context).textTheme.titleMedium),
      for (final cat in categories) _bar(cat, all.where((f) => f.category == cat).length, total),
    ]);
  }

  Widget _list(List<FeedbackItem> all) {
    final items = _filter == 'All' ? all : all.where((f) => f.category == _filter).toList();
    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(12),
        child: DropdownButtonFormField<String>(
          value: _filter,
          decoration: const InputDecoration(labelText: 'Filter by category', border: OutlineInputBorder()),
          items: ['All', ...categories].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
          onChanged: (v) => setState(() => _filter = v!),
        ),
      ),
      Expanded(
        child: items.isEmpty
            ? const Center(child: Text('No feedback found'))
            : ListView(children: items.map((f) => Card(
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${f.subject}  •  ${f.category}', style: const TextStyle(fontWeight: FontWeight.bold)),
                      Text(f.email, style: const TextStyle(fontSize: 12, color: Colors.grey)),
                      Stars(f.rating),
                      Text(f.comment),
                      Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                        TextButton(
                          onPressed: () => FirebaseService.setStatus(f.id, f.status == 'new' ? 'reviewed' : 'new'),
                          child: Text(f.status == 'new' ? 'Mark reviewed' : 'Mark pending'),
                        ),
                        IconButton(icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () => FirebaseService.delete(f.id)),
                      ]),
                    ]),
                  ),
                )).toList()),
      ),
    ]);
  }
}
