import 'package:flutter/material.dart';
import '../models.dart';
import '../services/firebase_service.dart';

class UserHome extends StatefulWidget {
  const UserHome({super.key});
  @override
  State<UserHome> createState() => _UserHomeState();
}

class _UserHomeState extends State<UserHome> {
  int _tab = 0;
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Feedback & Review'), actions: [
          IconButton(icon: const Icon(Icons.logout), onPressed: FirebaseService.logout),
        ]),
        body: _tab == 0 ? const _SubmitForm() : const _MyFeedback(),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _tab,
          onDestinationSelected: (i) => setState(() => _tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.edit_note), label: 'Submit'),
            NavigationDestination(icon: Icon(Icons.history), label: 'My feedback'),
          ],
        ),
      );
}

class Stars extends StatelessWidget {
  final int rating;
  final void Function(int)? onTap;
  const Stars(this.rating, {super.key, this.onTap});
  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(5, (i) => GestureDetector(
              onTap: onTap == null ? null : () => onTap!(i + 1),
              child: Icon(i < rating ? Icons.star : Icons.star_border,
                  color: Colors.amber, size: onTap == null ? 18 : 40),
            )),
      );
}

class _SubmitForm extends StatefulWidget {
  const _SubmitForm();
  @override
  State<_SubmitForm> createState() => _SubmitFormState();
}

class _SubmitFormState extends State<_SubmitForm> {
  String _cat = categories.first;
  int _rating = 0;
  final _subject = TextEditingController(), _comment = TextEditingController();
  bool _busy = false;

  void _msg(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _send() async {
    if (_subject.text.trim().isEmpty || _comment.text.trim().isEmpty || _rating == 0) {
      return _msg('Please add a subject, a rating and a comment');
    }
    setState(() => _busy = true);
    try {
      await FirebaseService.submit(_cat, _subject.text.trim(), _rating, _comment.text.trim());
      _subject.clear(); _comment.clear();
      setState(() => _rating = 0);
      _msg('Thank you! Feedback submitted');
    } catch (e) {
      _msg('Failed: $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
        DropdownButtonFormField<String>(
          value: _cat,
          decoration: const InputDecoration(labelText: 'Feedback about', border: OutlineInputBorder()),
          items: categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
          onChanged: (v) => setState(() => _cat = v!),
        ),
        const SizedBox(height: 12),
        TextField(controller: _subject,
            decoration: const InputDecoration(labelText: 'Subject (e.g. Flutter course)', border: OutlineInputBorder())),
        const SizedBox(height: 16),
        const Text('Your rating'),
        const SizedBox(height: 4),
        Stars(_rating, onTap: (v) => setState(() => _rating = v)),
        const SizedBox(height: 16),
        TextField(controller: _comment, maxLines: 5,
            decoration: const InputDecoration(labelText: 'Review / suggestion', border: OutlineInputBorder())),
        const SizedBox(height: 16),
        FilledButton.icon(onPressed: _busy ? null : _send, icon: const Icon(Icons.send),
            label: Text(_busy ? 'Sending...' : 'Submit feedback')),
      ]);
}

class _MyFeedback extends StatelessWidget {
  const _MyFeedback();
  @override
  Widget build(BuildContext context) => StreamBuilder<List<FeedbackItem>>(
        stream: FirebaseService.myFeedback(),
        builder: (c, s) {
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          if (s.data!.isEmpty) return const Center(child: Text('No feedback submitted yet'));
          return ListView(padding: const EdgeInsets.all(12), children: s.data!.map((f) => Card(
                child: ListTile(
                  title: Text('${f.subject}  •  ${f.category}'),
                  subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Stars(f.rating), Text(f.comment),
                  ]),
                  trailing: Chip(label: Text(f.status == 'new' ? 'Pending' : 'Reviewed')),
                ),
              )).toList());
        },
      );
}
